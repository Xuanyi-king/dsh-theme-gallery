# DSH 主题库

**简体中文（默认）** | [English](README.en.md)

一个插件，十一款主题。安装后在 DeepSeek Harness 的左侧「主题」中心中随时切换，也可以选「跟随 DSH」恢复默认；选中的主题在关闭并重新打开 DSH 后仍会保留。

主题设置提供「背景深淡」「侧栏遮罩」「背景模糊」「文字对比」四个滑条。深淡调节聊天场景的底色，侧栏遮罩独立调节左侧壁纸上方的底色，默认 40%，十一款主题共用；主题中心的半透明底色无需单独调节。拖动即可预览，数值保存在当前设备，重启后仍然有效；选择 DSH 内置主题时这些调节不会改变内置外观。模型生成回复期间，每款主题在原生状态栏显示自己的文字、用时与小型动态标记，兼容 DSH 0.2 的独立运行状态栏；启用系统的减少动态效果后，标记保持静止。

v0.3.18 修复 DSH 0.2.0-rc.2 的原生鲸鱼动效与主题标记叠加，并修复启动时旧配色覆盖已保存主题、导致文字变黑的问题。回复状态改为紧凑的单行标记，主题图标仅作轻微呼吸或浮动，文字与计时保持清晰。

v0.3.19 修复阿良、晴空守望、少年悟空被后端拒绝保存、重启后恢复成旧主题的问题。十款主题统一隐藏首页“预览版”标记，沿用相同的原生布局与功能控件；十款主题均接入各自配色、图标与文案的启动开场（山河保留水墨样板，其余九款使用专属矢量场景）。

| 主题 | 样图 | 风格 |
| --- | --- | --- |
| 山河剑意 | [查看样图](themes/shanhe/assets/concept-preview.webp) | 宣纸、水墨、朱砂、流动墨线 |
| 光之巨人（奥特曼灵感） | [查看样图](themes/ultraman/assets/concept-preview.webp) | 红银点缀、星空、蓝色能量核心 |
| 荒天帝意象（完美世界灵感） | [查看样图](themes/perfect-world/assets/concept-preview.webp) | 黑金战甲、赤色披风、诸天宫阙 |
| 炎帝意象（斗破苍穹灵感） | [查看样图](themes/flame-emperor/assets/concept-preview.webp) | 黑袍重尺、青色火莲、赤色火山 |
| 齐天大圣 | [查看样图](themes/great-sage/assets/concept-preview.webp) | 火眼金睛、金箍棒、云海天宫 |
| 哪吒 · 莲身破浪 | [查看样图](themes/nezha/assets/concept-preview.webp) | 混天绫、乾坤圈、火尖枪、风火轮 |
| 鲸少 · 沧海之主 | [查看样图](themes/whale-prince/assets/concept-preview.webp) | 男性海洋守望者、巨鲸、深海王城 |
| 阿良 · 雨夜行 | [查看样图](themes/jianlai-aliang/assets/concept-preview.webp) | 斗笠旅人、墨蓝雨夜、暖灯与剑光 |
| 晴空守望 | [查看样图](themes/sunny-watch/assets/concept-preview.webp) | 清晨城市、澄澈天空与温暖晨光 |
| 少年悟空 · 筋斗云之旅 | [查看样图](themes/young-goku/assets/concept-preview.webp) | 少年悟空、筋斗云、如意棒与晴空山河；非官方同人主题 |
| 王林 · 一念仙逆 | [查看样图](themes/wang-lin/assets/concept-preview.webp) | 白发银袍、冷灰雾山、暗红点缀与逆道赤印；《仙逆》非官方同人主题 |

主题图像使用新制作的视觉素材，涉及《龙珠》等作品角色的主题为非官方同人设计，不代表角色形象或相关知识产权为原创，也不代表获得官方授权。每款主题都有专属配色和场景图；背景覆盖 DSH 的实际对话区域，文字区域保留渐变遮罩以便阅读。运行提示使用 DSH 原生文字，避免装饰动画干扰阅读。
Windows 桌面版的顶栏使用对应主题的纯色，不透出场景壁纸；侧栏壁纸和侧栏遮罩仍可独立显示与调节。
主题会同时处理原有侧栏、聊天画布和输入卡片的视觉层；通过官方 slot 提供独立主题导航，不替换 DSH 原有功能按钮。山河主题使用水墨 WebP 场景，已停止使用旧版的抽象 SVG 山形。

v0.3.20 新增「王林 · 一念仙逆」（《仙逆》非官方同人主题）：白发银袍、冷灰雾山与暗红点缀。原生首页、侧栏、顶栏、输入区与运行状态统一采用新配色；逆道推演状态保留用时，赤银逆道印轻微呼吸，启动时薄雾与专属印记展开。沿用四个滑条和统一安装方式，无需新增安装包或命令。

## 安装

主题库是一个 bundle，安装一次就包含全部十一款主题。任选一条安装方式即可。

### 方式一：npm 包名（推荐）

注册表上的包名是 `@xuanyi-king/dsh-theme-gallery`（当前 `0.3.21`）。在 DSH 桌面应用中打开「插件 → 添加插件」，粘贴包名后点击「安装」：

```text
@xuanyi-king/dsh-theme-gallery
```

通过 Web profile 的命令行安装同样是一条命令：

```bash
dsh plugin --profile web add @xuanyi-king/dsh-theme-gallery
```

> registry 规格不会触发 GitHub 连通性预检（非 git 规格直接跳过），也不会克隆 git 历史，pnpm 只取 2.6MB 的发布包。实测：`registry.npmmirror.com` 约 2.75MB/s，冷 store 含依赖 6 秒装完，重跑 `pnpm install` 命中缓存 35ms；`registry.npmjs.org` 在受限网络下经常连不上。
>
> 直连 `registry.npmjs.org` 不稳时，在 profile 目录（`~/.dsh/profiles/desktop`）的 `.npmrc` 里加一行，只把本 scope 指向镜像：`@xuanyi-king:registry=https://registry.npmmirror.com/`。不要改成全局 registry —— profile 里依赖了多个很新的 alpha 版本，而 npmmirror 对它们的同步有延迟。
>
> 首次安装刚发布的版本时，pnpm 的供应链策略 `minimumReleaseAge` 会把它自动登记进 profile 的 `pnpm-workspace.yaml` 的 `minimumReleaseAgeExclude`（终端会打印 `Added 1 entry to minimumReleaseAgeExclude`），属正常行为，安装会继续。

### 方式二：CDN 发布包（registry 不可达时）

在 DSH 桌面应用中打开「插件 → 添加插件」，在输入框粘贴下面的 tarball 地址，点击「安装」：

```text
https://cdn.jsdmirror.com/gh/Xuanyi-king/dsh-theme-gallery@v0.3.21/artifacts/xuanyi-king-dsh-theme-gallery-0.3.21.tgz
```

通过 Web profile 的命令行安装时，也是一条命令：

```bash
dsh plugin --profile web add "https://cdn.jsdmirror.com/gh/Xuanyi-king/dsh-theme-gallery@v0.3.21/artifacts/xuanyi-king-dsh-theme-gallery-0.3.21.tgz"
```

> 该地址以 `.tgz` 结尾，DSH 会把它解析成远程 tarball 规格：非 git 规格不做 GitHub 连通性预检，pnpm 也不需要克隆 git 历史，只下载 2.6MB 的发布包（含依赖实测 3 秒左右装完）。
>
> `artifacts/` 里这份 tarball 与上传 npm 的是同一个文件：sha1 `63591cbdc9ae3784b1317d581d71f34410c36ff4`，sha512 `sha512-d2tyNOcC4ZaVJDVSs1aHSX8RDmjMXlmAbK1nKywjZHtESAtt6cQXbb7fbQEKejAxyvtQTyCFvoIBuwNZlneMcw==`。
>
> jsDelivr 各节点的可用性随网络差别极大，受限网络实测（2.6MB）：`cdn.jsdmirror.com` 0.5–3 秒 ✅、`testingcf.jsdelivr.net` 0.2–1 秒 ✅、`jsd.nn.ci` 0.7–3.4 秒 ✅、`jsdelivr.b-cdn.net` 3–4 秒 ✅、`fastly.jsdelivr.net` 与 `quantil.jsdelivr.net` 约 20 余秒、`cdn.jsdelivr.net` 连接会被重置 ❌、`gcore.jsdelivr.net` 证书会被劫持 ❌、`jsd.cdn.zzko.cn` 证书过期 ❌。**如果这个域名在你那里不通，把域名换成上面任一 ✅ 节点即可**，路径与文件完全相同（下载后可核对上面的 sha1）。
>
> pnpm 对「远程 tarball 依赖」有一个已知边角：当 tarball 已在 pnpm store 中、而锁文件里没有它的 integrity 字段时，会报 `ERR_PNPM_MISSING_TARBALL_INTEGRITY`。正常首次安装会下载并把 integrity 写进 `pnpm-lock.yaml`，之后 `pnpm install` 直接命中缓存（实测 35ms）。真遇到该报错时，把地址换成另一个节点域名重装即可（URL 变了会重新下载并补上 integrity），或先 `pnpm store prune` 清缓存再装。

> 不要再粘贴 GitHub 仓库地址安装。`https://github.com/...` 或 `github:` 规格会让 pnpm 克隆整份 git 历史（本仓库快照约 21MB），而且 DSH 在安装前会先做一次 GitHub 连通性预检（默认 5 秒超时），在 GitHub 受限的网络里会直接失败在 `spec-host`。

> 0.3.21 之前的发行包名是 `dsh-theme-gallery`（经 GitHub 地址安装）。改名是为了避开 npm 上与本项目无关的同名包。升级时请先移除旧的 `dsh-theme-gallery` 依赖，再安装新包名，否则两份 bundle 会同时插入插件。

安装后打开左侧「主题」中心，点击喜欢的主题卡片即可切换，不需要为每款主题分别安装插件。
升级后关闭、重开一次 DSH，加载新版插件；已保存的主题会自动恢复。已安装的旧版单款主题插件需要移除，避免同时覆盖界面样式。

## v0.3.21 独立主题中心与安全更新

在左侧「插件」下方点击「主题」，打开独立页面；侧栏折叠后可用调色盘图标，支持键盘及中英文。关闭页面不影响所选主题。原「设置 → 主题」注册已移除，启动开场仍使用 shell.overlay。

页面顶部显示实际运行 Client 版本、磁盘 manifest、安装来源、可靠时的锁定 commit、构建标识、DSH / Node 与远端目标。启动时只进行一次非阻塞检查，也可手动检查；不自动安装。先查可信的正式 GitHub Release，未发布 Release 时按固定仓库的默认分支 commit 获取 manifest 和 bundle，不读取 README 版本文本。运行 bundle、磁盘版本、安装锁定 commit、远端 HEAD 是不同事实。网络、代理、限流、超时、历史产物缺少构建元数据或版本落后均显示失败/未知，不伪称最新。

| DSH | v0.3.21 支持情况 |
| --- | --- |
| `0.2.1-alpha.1` | 本次主要适配目标，固定官方 tag 契约；真实 Web 验收详见验收记录 |
| `0.2.0-rc.2` | 旧版回归目标，相同 main/sidebar/connection 契约 |
| 其他 `0.2.x`（含 prerelease） | peer 声明为 `>=0.2.0-0 <0.3.0`，同一条 main/sidebar/connection 契约按 SemVer 自动匹配 |
| `0.1.x` 与 `>=0.3.0` | 未验证，不自动放宽 peer；选择相应兼容插件版本，不强行安装 |

Node 需要 `^22.19.0 || >=24`。DSH peer 为 `>=0.2.0-0 <0.3.0`：下界写成 `0.2.0-0` 而不是 `0.2.0`，这样 `0.2.0-rc.2`、`0.2.1-alpha.1` 这类预发布版本才在 SemVer 里可匹配，上界 `0.3.0` 防止跨大版本误装。同一个范围也写在 `engines.dsh`，供插件市场在安装前预判兼容性。

| 安装来源 | 检测与引导能力 |
| --- | --- |
| 固定官方仓库 GitHub | 分别检测依赖声明与锁定 commit，提示旧锁或 commit 未知；使用固定目标 |
| registry / 本地 `.tgz` | 检测当前声明版本、运行构建与产物；引导原生管理器，没有自动安装 |
| `link:` / junction / 本地目录 | 只读检测和备份；从源目录更新，不移动、不删除源目录 |
| 无法证明的来源 / 自定义宿主 | 明确未知或不支持；不尝试通用安装命令 |

点击「查看兼容性」返回结构化预检：DSH/Node、全部 DSH peers（真实 SemVer 与 prerelease）、固定目标产物、运行/磁盘一致性、目录可写、唯一 active 入口与恢复路径。不兼容阻止更新；未知保持未知。当前官方 Host 没有完整安全升级事务，即使预检其他项目通过，也只支持「保存恢复基线 → 下载基线 → 打开 DSH 插件详情」及操作说明。本插件不执行 npm/pnpm 安装、不串联卸载和安装、不升级宿主、不修改其他插件。

「重新验证运行状态」读取已保存的基线，检查实际磁盘/Host/Client、active、导航、图片解码、主题和四滑条与原始配置。基线 ID 在浏览器保存，重启后仍可核验；缺少证据不会显示成功。备份拒绝越过本插件目录的链接，保留原始文件字节及未知配置字段。

### 手动更新与失败恢复

1. 保存并下载恢复基线；本机副本只位于 `dsh-theme-gallery/update-baselines/<唯一 ID>.json`。记录原固定版本安装包、安装来源、锁定 commit 与当前 Profile。基线保留 `selection.json` 原始字节和未知字段、浏览器主题副本及四项外观参数；不复制整个 DSH_HOME。
2. 在独立终端或外部 Agent 检查 `dsh --version`、Node、安装源和目标 peer；确认原固定产物可用于恢复，再通过官方插件详情或与原来源匹配的机制处理本插件。GitHub 的普通 install 可能保留旧 lock commit，必须验证解析结果；不要删除整个锁文件或升级所有依赖。
3. Windows 上先完全退出 DSH 进程释放文件占用；关闭浏览器不能释放 Host。不要在正在被升级的插件/DSH 会话内执行安装。link/junction 指向的是源目录，绝不向未确认路径复制、移动或删除。
4. 完成后重新启动宿主、浏览器硬刷新；验证实际 Client/Host/manifest、锁定 commit、active 状态、主题导航、资源、原主题和四滑条。下载、安装、激活是三个不同阶段；结果未知先检查状态，不重复安装。
5. 下载失败保持原安装；安装失败从外部重装已记录原固定产物；Host 加载失败从外部恢复原版；页面失败先核对运行 Client 与缓存，再硬刷新。使用原路径还原基线中的 `selectionRaw` 到本插件 `selection.json`，保留备份。恢复浏览器仅还原 `dsh.themeGallery.selection` 和 `dsh.themeGallery.visual`（为 null 时删除对应键），不清空其他存储、不改其他插件。

运行与安装证据、故障注入及 Windows 验证限制见 [设计记录](docs/THEME-CENTER-UPGRADE-DESIGN.md) 和 [验收记录](docs/THEME-CENTER-ACCEPTANCE.md)。

## 切换、恢复与保存

左侧「主题」中心包含十一款主题和「跟随 DSH」「DSH 明亮」「DSH 深色」三个内置选项。选择「跟随 DSH」会清除主题库的覆盖设置，恢复 DSH 默认外观；随时可以再次选择主题。

选择会写入 DSH 本机配置目录中的 `dsh-theme-gallery/selection.json`；页面同时保存本地副本，供宿主未提供配置接口时恢复。重启 DSH 后会重新读取选择。如果此前安装过旧版单款主题插件，请先移除那些旧插件，避免旧版装饰同时运行。

## 主题启动动画

保存任意一款主题库主题后，重新打开或刷新 DSH 页面，会展示约 4 秒的专属开场。十一款主题均使用现有壁纸与代码动画，不需要视频、音频或联网素材。山河保留原有水墨样板；其他十款采用各自的图形、光效与构图。

| 主题 | 开场效果 |
| --- | --- |
| 山河剑意 | 墨线展开，朱砂印章与主题文案入场 |
| 光之巨人 | 蓝色能量核心点亮，星光轨道缓缓转动 |
| 荒天帝 | 黑金日轮展开，符纹与金色星芒浮现 |
| 炎帝 | 青色火莲绽放，暖色余烬向上飘动 |
| 齐天大圣 | 云海散开，金棒光痕划过 |
| 哪吒 | 赤色绫带舒展，莲瓣与火轮展开 |
| 鲸少 | 深海光束、潮汐圆环与缓慢上升的气泡 |
| 阿良 | 细雨斜落，暖灯微光与短暂剑光 |
| 晴空守望 | 晨光铺开，太阳与城市轮廓入场 |
| 少年悟空 | 轻盈云迹、金色轨道与明亮的少年文案 |
| 王林 | 冷灰薄雾展开，赤银逆道印浮现，凡心问道文案入场 |

桌面版将文字放在场景左侧留白处；窄屏将文字移到下方，并调整壁纸裁切，尽量保留人物面部。

点右上角「跳过」或按 Esc 可以立即关闭。动画只在页面启动时播放一次，切换主题和打开新对话不会重播。选择 DSH 内置主题，或系统启用「减少动态效果」时，不显示开场。

播放前会等待已保存的主题恢复。如果宿主配置请求超过 1.5 秒仍未完成，则按本地已保存的主题决定是否播放；稍后收到配置也不会再次弹出。启动期间手动选择主题，也不会触发延迟播放。

## 开发与验证

```bash
npm run build
npm test
npm run pack:gallery
```

仓库根目录是统一安装包。各款主题的资源保留在 `themes/<name>/`，便于继续迭代；王林目录仅提供统一插件使用的配色和素材，不含单款插件清单或安装包。十款旧主题的独立资源与测试保留；本次启动动画只接入统一安装包，不改动单款主题包。

可选浏览器验证使用真实 React 和已构建的 `lib/client.js`，覆盖十一款主题的桌面、手机及 320px 窄屏布局，以及跳过、Esc、自动关闭、减少动态效果和主题恢复。先在仓库外安装 `playwright`、`react@18` 和 `react-dom@18`，并安装 Playwright Chromium，再运行：

```bash
DSH_INTRO_BROWSER_TOOLS=/你的浏览器工具目录 node scripts/verify-startup-browser.mjs
```

默认截图和离线预览保存到 `/tmp/dsh-theme-intros-preview/`。用浏览器打开 `theme-intros.html`，通过下拉菜单或主题卡片选择开场；动画结束后，点击「重播当前开场」即可再次查看。预览页不读写浏览器中已有的主题设置；主题选择与重播只用于展示，不改变真实插件的启动播放规则。原有 `shanhe-preview.html` 也会保留。

也可设置 `DSH_INTRO_BROWSER_EXECUTABLE` 指向已安装的 Chromium 系浏览器可执行文件，例如 Windows 的 Microsoft Edge，无需另行下载 Playwright Chromium。

浏览器测试使用模拟 DSH 服务，安装到实际 DSH 后仍需检查宿主内效果。

## 许可与角色说明

代码采用 MIT 许可，见 [LICENSE](LICENSE)。涉及作品角色的主题属于非官方同人设计，不代表获得原作授权；角色及相关知识产权仍属于各自权利人。
